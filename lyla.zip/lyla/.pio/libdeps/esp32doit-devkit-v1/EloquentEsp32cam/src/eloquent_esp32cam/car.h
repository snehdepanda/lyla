#ifndef ELOQUENTESP32CAM_CAR_H
#define ELOQUENTESP32CAM_CAR_H

#include "./car/fomo_driven_car.h"

#endif
