#ifndef ELOQUENT_EDGEIMPULSE
#define ELOQUENT_EDGEIMPULSE

#include "./eloquent_edgeimpulse/impulse.h"

#endif